package editor;

public class Main {

	
	public static void main(String[] args)
	{
		//BMPFormatter bmpFormatter = new BMPFormatter();
		
		//bmpFormatter.loadImage("pic.bmp");
		
		//bmpFormatter.exportImage("Hehe.bmp");
		
		
		Image img = new Image();
		
		img.showImage("pic.bmp");
	}
}
