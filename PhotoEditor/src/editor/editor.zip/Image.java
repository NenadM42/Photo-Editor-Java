package editor;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Image {

	
	
	
	public void showImage(String path)
	{
		
		JFrame frame = new JFrame();
		
		File imageFile = new File(path);
		
		BufferedImage i = null;
		try {
			i = ImageIO.read(imageFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ImageIcon icon = new ImageIcon(i);
		JLabel label = new JLabel(icon);
		
		
		frame.setSize(200, 200);
		frame.add(label);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		
		
	}
}
