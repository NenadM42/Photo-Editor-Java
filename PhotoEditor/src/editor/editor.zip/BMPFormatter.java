package editor;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class BMPFormatter {

	
	File bmpFile;
	BufferedImage image;
	
	
	
	public void loadImage(String path)
	{
		bmpFile = new File(path);
		try {
			image = ImageIO.read(bmpFile);
		} catch (IOException e) {
			System.out.println("Nije lepo procitana slika!");
		}
	}
	
	
	public void exportImage(String path)
	{
		try {
			ImageIO.write(image,"BMP",new File(path));
		} catch (IOException e) {
			System.out.println("Nije lepo exportovana slika!");
		}
	}
	
	
	
	
}




